from django.apps import AppConfig


class DjangoEmailConfimConfig(AppConfig):
    name = 'email_verification'
